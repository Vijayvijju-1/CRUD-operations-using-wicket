package org.planon.project.User;

import java.io.Serializable;


@SuppressWarnings("serial")
public class User implements Serializable {
	private String name;
	private String email;
	private String phno;
	private int id;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhno() {
		return phno;
	}
	public void setPhno(String l) {
		this.phno = l;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
