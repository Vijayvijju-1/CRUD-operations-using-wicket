package org.planon.project.User;

import java.sql.*;
import java.util.*;

import org.apache.wicket.extensions.markup.html.repeater.util.SortParam;

public class UserDataBase {
	Map<String,User> data = new HashMap<>();
	List<User> list=new ArrayList<>();
	List<User> name=new ArrayList<>();
	List<User> idDes = new ArrayList<>();
	List<User> idAs = new ArrayList<>();
	List<String> nameAsc=new ArrayList<>();

	public Connection connectDB() throws ClassNotFoundException, SQLException
	{
		String un = "root";
		String p = "Vijaykumar@123";
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url= "jdbc:mysql://localhost:3306/hello";
		Connection con = DriverManager.getConnection(url, un, p);
		return con;
	}
	
	public UserDataBase() throws ClassNotFoundException, SQLException
	{
		Statement st = connectDB().createStatement();
		ResultSet rs = st.executeQuery("select * from user");
		while(rs.next())
		{
			User obj = new User();
			int id = rs.getInt(4);
			obj.setId(id);
			obj.setName(rs.getString(1));
			obj.setEmail(rs.getString(2));
			obj.setPhno(rs.getString(3));
			name.add(obj);
			list.add(obj);
			nameAsc.add(obj.getName());
			data.put(rs.getString(1), obj);
			idDes.add(obj);
			idAs.add(obj);
			
		}
		System.out.println(nameAsc);
		UpdateSort();
	}
	public List<User> getList() {
		return this.list;
	}
//	public User get(int id)
//	{
//		User c = data.get(id);
//		if (c == null)
//		{
//			throw new RuntimeException("contact with id [" + id + "] not found in the database");
//		}
//		return c;
//	}
	public int getCount()
	{
		return idDes.size();
	}
	public List<User> getIndex(SortParam<?> sort)
	{
		if (sort == null)
		{
			return idAs;
		}

		if (sort.getProperty().equals("id"))
		{
			return sort.isAscending() ?  idAs: idDes;//conditional operator
		}
		else if (sort.getProperty().equals("name"))
		{
			//return sort.isAscending() ? nameAs : nameDes;
		}
		throw new RuntimeException("unknown sort option [" + sort +
			"]. valid fields: [firstName], [lastName]");
	}
	public void UpdateSort()
	{
		Collections.sort(idAs, (arg0, arg1) -> (arg0).getId()-(arg1).getId());
		Collections.sort(nameAsc);
		Collections.sort(idDes, (arg0, arg1) -> (arg1).getId()-(arg0).getId());
		System.out.println(nameAsc);
		//Collections.sort(nameDes, (arg0, arg1) -> (arg1).getName().compareTo((arg0).getName()));
		//Collections.sort(nameAs, (arg0, arg1) -> (arg0).getName().compareTo((arg1).getName()));
	}
}
