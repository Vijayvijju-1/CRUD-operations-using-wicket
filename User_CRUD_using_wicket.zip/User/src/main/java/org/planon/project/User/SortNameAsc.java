
package org.planon.project.User;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.extensions.ajax.markup.html.modal.ModalWindow;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.request.mapper.parameter.PageParameters;

@SuppressWarnings("deprecation")
public class SortNameAsc extends WebPage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SortNameAsc(final PageParameters parameters) throws ClassNotFoundException, SQLException {

		
			UserDataBase object = new UserDataBase();
			try {
				
			

				ModalWindow resultWindow = new ModalWindow("editUserForm");
				ModalWindow confirmWindow=new ModalWindow("confirm");
				//Label sortName=new Label("sortName","User ID");
				Label sortN=new Label("sortN","Name");
				//Label sortEmail=new Label("sortEmail","User ID");
				//add(sortName);
	           add(confirmWindow);
				add(resultWindow);
//				sortName.add(new AjaxEventBehavior("click") {
//					/**
//					 * 
//					 */
//					private static final long serialVersionUID = 1L;
//
//					protected void onEvent(AjaxRequestTarget target) {
//						
//						setResponsePage(UserData.class);
//
//						
//						
//					}
//				});
				sortN.add(new AjaxEventBehavior("click") {
					/**
					 * 
					 */
					private static final long serialVersionUID = 1L;

					protected void onEvent(AjaxRequestTarget target) {
						
						setResponsePage(UserData.class);

						
						
					}
				});
//				sortEmail.add(new AjaxEventBehavior("click") {
//					/**
//					 * 
//					 */
//					private static final long serialVersionUID = 1L;
//
//					protected void onEvent(AjaxRequestTarget target) {
//						
//						setResponsePage(UserData.class);
//
//						
//						
//					}
//				});
				
				WebMarkupContainer userTable = new WebMarkupContainer("userTable");
				userTable.setOutputMarkupId(true);
				//userTable.add(sortName);
				userTable.add(sortN);
				add(userTable);
			
//				@SuppressWarnings("null")
				List<User> list=new ArrayList<>();
				Map<String,User> hm=object.data;
			for(User obj:hm.values()) {
				list.add(obj);
			}
				ListView<User> listView = new ListView<User>("userRecord",list) {
					private static final long serialVersionUID = 1L;

					
					protected void populateItem(ListItem<User> item) {
	                    // item.add(sortName);
						 User user = item.getModelObject();
						
						 Label update=new Label("update", "Update");
						 Label delete=new Label("delete","Remove");
						
						item.add(new Label("id", user.getId()));
						item.add(new Label("name", user.getName()));
						item.add(new Label("email",user.getEmail()));
						item.add(new Label("phone", user.getPhno()));
						item.add(delete);
						item.add(update);
						update.add(new AjaxEventBehavior("click") {
							private static final long serialVersionUID = 1L;

							@Override
							protected void onEvent(AjaxRequestTarget target) {
								var id=user.getId();
								
								EditUser editUser;
								try {
									editUser = new EditUser(resultWindow.getContentId(),id,userTable);
									resultWindow
									.setContent(editUser);
							resultWindow.show(target);
								} catch (ClassNotFoundException | SQLException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								
								//resultWindow.setTitle("Edit Details");
							}
						
					
				});
					
						delete.add(new AjaxEventBehavior("click") {
							private static final long serialVersionUID = 1L;

							@Override
							protected void onEvent(AjaxRequestTarget target) {
								var id=user.getId();
								
								DeleteUser deleteUser = new DeleteUser(confirmWindow.getContentId(),id,userTable);
								confirmWindow
										.setContent(deleteUser);
								confirmWindow.show(target);
								//confirmWindow.setTitle("Delete User");
							}

						});
						
						

					}

					
				};
				userTable.add(listView);
			} catch (Exception e) {
				PageParameters parameters1 = new PageParameters();
				parameters1.add("msg", e.getMessage());
				//setResponsePage(ErrorPage.class, parameters1);
			}
		}

}
