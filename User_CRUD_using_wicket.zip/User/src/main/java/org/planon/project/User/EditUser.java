package org.planon.project.User;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.wicket.ajax.AjaxEventBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.extensions.ajax.markup.html.modal.ModalWindow;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.EmailTextField;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.panel.FeedbackPanel;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.Model;

@SuppressWarnings({ "serial", "deprecation" })
public class EditUser extends Panel {

	public EditUser(String contentId, int id, WebMarkupContainer empTable) throws ClassNotFoundException, SQLException {
		super(contentId);
		UserDataBase user=new UserDataBase();
		Connection con=user.connectDB();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from user where id='"+id+"'");
		rs.next();
		//System.out.println(id);
		FeedbackPanel feedbackPanel = new FeedbackPanel("feedback");
		//System.out.println("linne 32");
		feedbackPanel.setOutputMarkupId(true);
		final TextField<String> name = new TextField<String>("name",Model.of(rs.getString(1)));
		name.setRequired(true);
		final EmailTextField email = new EmailTextField("email",Model.of(rs.getString(2)));
		email.setRequired(true);
		final  TextField<String> phoneno = new  TextField<String>("phoneno",Model.of(rs.getString(3)));
		phoneno.setRequired(true);
		//System.out.println("linne 41");
        name.setDefaultModel(Model.of(name.getValue()));
        email.setDefaultModel(Model.of(email.getValue()));

        phoneno.setDefaultModel(Model.of(phoneno.getValue()));

		Form<?> form = new Form<Void>("empForm");
		Button submitButton = new AjaxButton("editButton") {

			
			private static final long serialVersionUID = 1L;

			@SuppressWarnings({})
			@Override
			protected void onSubmit(AjaxRequestTarget target) {
                try {
					UserDataBase o=new UserDataBase();
					Connection con =o.connectDB();
					Statement st=con.createStatement();
				    st.executeUpdate("update  user set name='"+name.getValue()+"',email='"+email.getValue()+"',phno='"+phoneno.getValue()+"' where id='"+id+"'");
				    super.onSubmit(target);
					ModalWindow.closeCurrent(target);
					target.add(empTable);
					setResponsePage(UserData.class);
					//System.out.println("hello");
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println(e.getMessage());
				}
                
				
			}

			@Override
			protected void onError(AjaxRequestTarget target) {
				super.onError(target);
				target.add(feedbackPanel);
			}
		};
		/*
		 * Button cancelButton = new AjaxButton("cancelButton") {
		 * 
		 * @Override protected void onSubmit(AjaxRequestTarget target) {
		 * super.onSubmit(target); ModalWindow.closeCurrent(target);
		 * target.add(empTable); } };
		 */

		Button cancelButton = new Button("cancelButton");
		cancelButton.add(new AjaxEventBehavior("click") {
			private static final long serialVersionUID = 1L;

			@Override
			protected void onEvent(AjaxRequestTarget target) {
				ModalWindow.closeCurrent(target);
				setResponsePage(UserData.class);

			}
		});

		form.add(name);
		form.add(email);
		form.add(phoneno);
		form.add(submitButton);
		form.add(cancelButton);
		form.add(feedbackPanel);
		add(form);

	}

	}

